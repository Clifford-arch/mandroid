import React from "react";
import { View, Text } from "react-native";
import Swiper from 'react-native-swiper';
import Indian from "./Indian";
// import Indian from "./indian";

const MarketsOverview1 = () => {
  return (
    <View>
      <View>
        <View>
          <View>
            <Swiper
              showsButtons={true}
              showsPagination={true}
              loop={false}
            >
              <View>
                {/* <Indian /> */}
                <Indian/>
              </View>
            </Swiper>
          </View>
        </View>
      </View>
    </View>
  );
};

export default MarketsOverview1;